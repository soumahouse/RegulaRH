"""Vercel ASGI entrypoint for REGULA-RH.

This file replaces the Streamlit `app.py` for Vercel deployment.
Keep the Streamlit interface as `streamlit_app.py` for local use:
    streamlit run streamlit_app.py

Vercel requires a top-level ASGI/WSGI variable named `app`.
"""
from __future__ import annotations

import os
from datetime import date
from typing import Any

# Vercel serverless filesystems are ephemeral. Use /tmp for the demo SQLite DB.
# For production, replace SQLite with a persistent database such as Postgres.
if os.environ.get("VERCEL") and not os.environ.get("REGULA_RH_DB"):
    os.environ["REGULA_RH_DB"] = "/tmp/regula_rh.db"

import pandas as pd
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse

from algorithm import generate_daily_planning
from database import init_db, load_demo_data, query_df

app = FastAPI(
    title="REGULA-RH Vaccipha × Umed",
    version="1.0.0-vercel",
    description="API minimale Vercel pour le MVP REGULA-RH.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def _init() -> None:
    """Ensure the local/ephemeral DB schema exists before every operation."""
    init_db()


def _df_to_records(df: pd.DataFrame) -> list[dict[str, Any]]:
    if df.empty:
        return []
    return df.where(pd.notnull(df), None).to_dict(orient="records")


@app.get("/", response_class=HTMLResponse)
def home() -> str:
    _init()
    return """
    <!doctype html>
    <html lang="fr">
    <head>
      <meta charset="utf-8" />
      <meta name="viewport" content="width=device-width, initial-scale=1" />
      <title>REGULA-RH Vaccipha × Umed</title>
      <style>
        body { font-family: Arial, sans-serif; margin: 40px; color: #16213e; }
        .card { max-width: 900px; border: 1px solid #e5e7eb; border-radius: 16px; padding: 28px; box-shadow: 0 8px 24px rgba(0,0,0,.06); }
        h1 { margin-top: 0; }
        code { background: #f3f4f6; padding: 3px 6px; border-radius: 6px; }
        a { color: #0f766e; font-weight: 600; }
        .warn { background: #fff7ed; border-left: 4px solid #f97316; padding: 12px; margin: 18px 0; }
        li { margin: 8px 0; }
      </style>
    </head>
    <body>
      <div class="card">
        <h1>REGULA-RH Vaccipha × Umed</h1>
        <p>Déploiement Vercel actif. Cette version expose une API FastAPI compatible Vercel.</p>
        <div class="warn">
          <strong>Note :</strong> l'interface Streamlit complète doit être lancée en local avec
          <code>streamlit run streamlit_app.py</code>. Sur Vercel, la base SQLite est démonstrative
          et non persistante. Pour la production, utiliser une base Postgres persistante.
        </div>
        <h2>Endpoints utiles</h2>
        <ul>
          <li><a href="/api/health">/api/health</a> — contrôle de santé</li>
          <li><a href="/api/dashboard">/api/dashboard</a> — indicateurs principaux</li>
          <li><a href="/api/planning">/api/planning</a> — planning du jour</li>
          <li><a href="/docs">/docs</a> — documentation interactive API</li>
        </ul>
        <h2>Initialiser les données de démonstration</h2>
        <p>Depuis un terminal :</p>
        <pre>curl -X POST https://VOTRE-DOMAINE.vercel.app/api/demo</pre>
      </div>
    </body>
    </html>
    """


@app.get("/api/health")
def health() -> dict[str, Any]:
    _init()
    return {"status": "ok", "service": "regula-rh", "date": date.today().isoformat()}


@app.post("/api/demo")
def demo() -> dict[str, Any]:
    _init()
    load_demo_data()
    return {"status": "ok", "message": "Données de démonstration chargées si la base était vide."}


@app.post("/api/generate-planning")
def api_generate_planning(target_date: str = Query(default_factory=lambda: date.today().isoformat(), alias="date")) -> dict[str, Any]:
    _init()
    try:
        result = generate_daily_planning(target_date)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc
    return {"status": "ok", "date": target_date, "result": result}


@app.get("/api/dashboard")
def dashboard(target_date: str = Query(default_factory=lambda: date.today().isoformat(), alias="date")) -> JSONResponse:
    _init()
    try:
        agents = query_df("SELECT * FROM agents")
        pharmacies = query_df("SELECT * FROM pharmacies WHERE statut='active'")
        demandes = query_df("SELECT * FROM demandes_umed WHERE date_demande<=?", (target_date,))
        planning = query_df("SELECT * FROM planning WHERE date=?", (target_date,))
        couts = query_df("SELECT * FROM couts_journaliers WHERE date=?", (target_date,))
        alertes = query_df("SELECT * FROM alertes WHERE date=?", (target_date,))

        covered_pharmacies = planning[planning["type_affectation"] == "pharmacie"]["reference_id"].nunique() if not planning.empty else 0
        affected_umed = planning[planning["type_affectation"] == "mission Umed"]["reference_id"].nunique() if not planning.empty else 0
        active_pharmacies = len(pharmacies)
        total_demandes = len(demandes)

        payload: dict[str, Any] = {
            "date": target_date,
            "agents_total": len(agents),
            "agents_AS": int((agents["categorie_agent"] == "AS").sum()) if not agents.empty else 0,
            "agents_IDE": int((agents["categorie_agent"] == "IDE").sum()) if not agents.empty else 0,
            "pharmacies_actives": active_pharmacies,
            "pharmacies_couvertes": int(covered_pharmacies),
            "taux_couverture_pharmacies": round((covered_pharmacies / active_pharmacies) * 100, 2) if active_pharmacies else 0,
            "demandes_umed": total_demandes,
            "demandes_umed_affectees": int(affected_umed),
            "taux_couverture_umed": round((affected_umed / total_demandes) * 100, 2) if total_demandes else 0,
            "agents_mobilises": int(planning["agent_id"].nunique()) if not planning.empty else 0,
            "couts": _df_to_records(couts),
            "alertes": _df_to_records(alertes),
        }
        return JSONResponse(payload)
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/api/planning")
def api_planning(target_date: str = Query(default_factory=lambda: date.today().isoformat(), alias="date")) -> list[dict[str, Any]]:
    _init()
    df = query_df("SELECT * FROM planning WHERE date=? ORDER BY type_affectation, cluster, agent_id", (target_date,))
    return _df_to_records(df)


@app.get("/api/agents")
def api_agents() -> list[dict[str, Any]]:
    _init()
    return _df_to_records(query_df("SELECT * FROM agents ORDER BY categorie_agent, nom, prenom"))


@app.get("/api/pharmacies")
def api_pharmacies() -> list[dict[str, Any]]:
    _init()
    return _df_to_records(query_df("SELECT * FROM pharmacies ORDER BY cluster, nom_pharmacie"))


@app.get("/api/demandes-umed")
def api_demandes() -> list[dict[str, Any]]:
    _init()
    return _df_to_records(query_df("SELECT * FROM demandes_umed ORDER BY date_demande DESC, priorite, id_demande"))
