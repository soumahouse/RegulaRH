# Correctif Vercel — REGULA-RH

## Cause de l'erreur

Vercel détecte le fichier `app.py` et attend une variable ASGI/WSGI nommée `app`, `application` ou un `handler`. L'ancien `app.py` est une application Streamlit et ne déclare pas cette variable.

## Correctif appliqué

- Renommer l'interface Streamlit en `streamlit_app.py`.
- Remplacer `app.py` par un point d'entrée FastAPI compatible Vercel.
- Ajouter `fastapi` dans `requirements.txt`.
- Garder l'interface Streamlit utilisable en local avec :

```bash
streamlit run streamlit_app.py
```

## Déploiement GitHub / Vercel

```bash
git mv app.py streamlit_app.py
# Copier le nouveau app.py, requirements.txt et vercel.json à la racine du repo
git add .
git commit -m "Fix Vercel ASGI entrypoint for REGULA-RH"
git push origin main
```

## Test après déploiement

Ouvrir :

- `/api/health`
- `/docs`
- `/api/dashboard`

Pour charger les données de démonstration :

```bash
curl -X POST https://VOTRE-DOMAINE.vercel.app/api/demo
```

Puis générer le planning :

```bash
curl -X POST "https://VOTRE-DOMAINE.vercel.app/api/generate-planning"
```

## Limite importante

Cette correction rend le projet déployable sur Vercel, mais Vercel n'est pas adapté à l'interface Streamlit complète. La version Vercel expose une API et une page d'accueil minimale. En production, remplacer SQLite par une base persistante, par exemple Postgres.
